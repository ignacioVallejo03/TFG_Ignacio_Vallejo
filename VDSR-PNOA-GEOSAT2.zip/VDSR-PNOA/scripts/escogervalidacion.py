import os
import random
import shutil

# Rutas
hr_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/train/hr'
lr_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/train/lr'
valid_hr_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/valid/hr'
valid_lr_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/valid/lr'

# Crear carpetas de validación si no existen
os.makedirs(valid_hr_dir, exist_ok=True)
os.makedirs(valid_lr_dir, exist_ok=True)

# Obtener nombres de archivos comunes
hr_files = sorted(os.listdir(hr_dir))
lr_files = sorted(os.listdir(lr_dir))

# Filtrar solo los que existen en ambos directorios
common_files = list(set(hr_files) & set(lr_files))
common_files.sort()

# Seleccionar el 10% aleatoriamente
num_to_select = max(1, int(len(common_files) * 0.1))
selected_files = random.sample(common_files, num_to_select)

# Copiar los archivos seleccionados
for fname in selected_files:
    shutil.copy(os.path.join(hr_dir, fname), os.path.join(valid_hr_dir, fname))
    shutil.copy(os.path.join(lr_dir, fname), os.path.join(valid_lr_dir, fname))

print(f"Se copiaron {len(selected_files)} pares a 'valid/hr' y 'valid/lr'.")
