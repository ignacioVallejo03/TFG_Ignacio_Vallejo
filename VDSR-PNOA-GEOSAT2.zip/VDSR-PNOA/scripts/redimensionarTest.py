import os
import cv2

# Ruta de entrada y salida
input_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/testcombinados/gsat'
output_dir = 'H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/testGsat768'

# Crear carpeta de salida si no existe
os.makedirs(output_dir, exist_ok=True)

# Recorrer imágenes en carpeta de entrada
for filename in os.listdir(input_dir):
    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
        img_path = os.path.join(input_dir, filename)
        img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)

        # Redimensionar a 768x768 con interpolación Lanczos
        img_resized = cv2.resize(img, (768, 768), interpolation=cv2.INTER_AREA)

        # Guardar imagen redimensionada
        output_path = os.path.join(output_dir, filename)
        cv2.imwrite(output_path, img_resized)

print("Redimensionamiento completo.")
