import os
from PIL import Image

# Ruta a las imágenes LR originales
lr_dir = "H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/train/hr126"
# Ruta para guardar las imágenes LR redimensionadas
output_dir = "H:/ignacio/MODELO/VDSR_PNOA/VDSR-PNOA/data/gsat42_pnoa42/train/hrbox"

# Crear la carpeta de salida si no existe
os.makedirs(output_dir, exist_ok=True)

# Dimensiones deseadas
target_size = (42, 42)

# Iterar sobre todas las imágenes
for filename in os.listdir(lr_dir):
    if filename.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tiff")):
        # Abrir la imagen
        img_path = os.path.join(lr_dir, filename)
        img = Image.open(img_path).convert("RGB")

        # Redimensionar con interpolación por vecino más próximo
        img_resized = img.resize(target_size, Image.Resampling.BOX)

        # Guardar en la carpeta de salida
        save_path = os.path.join(output_dir, filename)
        img_resized.save(save_path)

        print(f"Guardada: {save_path}")
