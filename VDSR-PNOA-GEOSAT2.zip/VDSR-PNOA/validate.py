import os
import cv2
import numpy as np
import torch
from natsort import natsorted
from skimage.metrics import structural_similarity as ssim  # ← SSIM

import config
import imgproc
from model import VDSR


def main() -> None:
    # Inicializa el modelo
    model = VDSR().to(config.device)
    print("Modelo VDSR construido exitosamente.")

    checkpoint = torch.load(config.model_path, map_location=lambda storage, loc: storage)
    model.load_state_dict(checkpoint["state_dict"])
    print(f"Pesos del modelo VDSR cargados `{os.path.abspath(config.model_path)}` exitosamente.")

    results_dir = os.path.join("results", "test", config.exp_name)
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    model.eval()
    model.half()

    total_psnr = 0.0
    total_ssim = 0.0
    psnr_count = 0

    file_names = natsorted(os.listdir(config.lr_dir))
    total_files = len(file_names)

    for index in range(total_files):
        lr_image_path = os.path.join(config.lr_dir, file_names[index])
        hr_image_path = os.path.join(config.hr_dirc, file_names[index])

        print(f"Procesando `{os.path.abspath(hr_image_path)}`...")

        lr_image = cv2.imread(lr_image_path).astype(np.float32) / 255.0
        hr_image = cv2.imread(hr_image_path).astype(np.float32) / 255.0

        lr_ycbcr_image = imgproc.bgr2ycbcr(lr_image, use_y_channel=False)
        hr_ycbcr_image = imgproc.bgr2ycbcr(hr_image, use_y_channel=False)

        lr_y_image, lr_cb_image, lr_cr_image = cv2.split(lr_ycbcr_image)
        hr_y_image, hr_cb_image, hr_cr_image = cv2.split(hr_ycbcr_image)

        lr_y_tensor = imgproc.image2tensor(lr_y_image, range_norm=False, half=True).to(config.device).unsqueeze_(0)
        hr_y_tensor = imgproc.image2tensor(hr_y_image, range_norm=False, half=True).to(config.device).unsqueeze_(0)

        with torch.no_grad():
            sr_y_tensor = model(lr_y_tensor).clamp_(0, 1.0)

        # Calcular PSNR solo si el MSE no es extremadamente pequeño
        mse = torch.mean((sr_y_tensor - hr_y_tensor) ** 2).item()
        if mse < 1e-10:
            print(f"[AVISO] MSE ≈ 0 (mse={mse:.2e}), PSNR infinito en: {file_names[index]}")
        else:
            psnr = 10. * np.log10(1. / mse)
            total_psnr += psnr
            psnr_count += 1

        # Convertir tensor a imagen
        sr_y_image = imgproc.tensor2image(sr_y_tensor, range_norm=False, half=True)
        sr_y_image = sr_y_image.astype(np.float32) / 255.0

        # Ajustar dimensiones para SSIM
        min_height = min(hr_y_image.shape[0], sr_y_image.shape[0])
        min_width = min(hr_y_image.shape[1], sr_y_image.shape[1])
        hr_y_resized = cv2.resize(hr_y_image, (min_width, min_height))
        sr_y_resized = cv2.resize(sr_y_image, (min_width, min_height))

        hr_y_uint8 = (hr_y_resized * 255.0).astype(np.uint8)
        sr_y_uint8 = (sr_y_resized * 255.0).astype(np.uint8)
        total_ssim += ssim(hr_y_uint8, sr_y_uint8)

        # Guardar imagen SR final
        sr_ycbcr_image = cv2.merge([sr_y_image, hr_cb_image, hr_cr_image])
        sr_image = imgproc.ycbcr2bgr(sr_ycbcr_image)
        cv2.imwrite(lr_image_path.replace(config.lr_dir, results_dir), sr_image * 255.0)

    if psnr_count > 0:
        print(f"PSNR: {total_psnr / psnr_count:4.2f}dB. (calculado sobre {psnr_count}/{total_files} imágenes)")
    else:
        print("No se pudo calcular PSNR para ninguna imagen (todas tienen PSNR infinito).")

    print(f"SSIM: {total_ssim / total_files:4.4f}")


if __name__ == "__main__":
    main()
